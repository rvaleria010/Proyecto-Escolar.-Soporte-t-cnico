"""Pruebas del alta de solicitudes y folio consecutivo (S2-16, HU-01.1)."""

import asyncio
import uuid

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import StaticPool

import app.models  # noqa: F401
from app.api.dependencies import get_current_user
from app.api.routers.solicitudes import get_clasificacion_service
from app.db.base import Base
from app.db.session import get_session
from app.main import app as fastapi_app
from app.models.enums import UserType
from app.models.identity import User


def _create_engine_and_maker():
    engine = create_async_engine(
        "sqlite+aiosqlite://",
        poolclass=StaticPool,
        connect_args={"check_same_thread": False},
    )
    maker = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    return engine, maker


def _seed_users(maker: async_sessionmaker, requester_id: uuid.UUID) -> None:
    async def prepare() -> None:
        async with maker() as session:
            session.add(
                User(
                    id=requester_id,
                    institutional_id=f"req-{requester_id.hex[:8]}",
                    full_name="Solicitante de prueba",
                    email=f"req-{requester_id.hex[:8]}@example.test",
                    user_type=UserType.ACADEMIC,
                    is_active=True,
                )
            )
            await session.commit()

    asyncio.run(prepare())


def _override_session(maker: async_sessionmaker):
    async def override():
        async with maker() as session:
            yield session

    return override


def _override_get_current_user(maker: async_sessionmaker, user_id: uuid.UUID):
    async def override() -> User:
        async with maker() as session:
            return await session.get(User, user_id)

    return override


@pytest.fixture
def request_client():
    """Cliente autenticado: el solicitante de prueba inicia sesión."""
    engine, maker = _create_engine_and_maker()
    requester_id = uuid.uuid4()
    category_id = uuid.uuid4()

    async def prepare() -> None:
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    asyncio.run(prepare())
    _seed_users(maker, requester_id)

    fastapi_app.dependency_overrides[get_session] = _override_session(maker)
    fastapi_app.dependency_overrides[get_current_user] = _override_get_current_user(
        maker, requester_id
    )
    # S4-13: aquí solo se prueba el registro; la clasificación va en test_alta_clasificada.py.
    fastapi_app.dependency_overrides[get_clasificacion_service] = lambda: None
    try:
        yield TestClient(fastapi_app), requester_id, category_id
    finally:
        fastapi_app.dependency_overrides.clear()
        asyncio.run(engine.dispose())


@pytest.fixture
def unauthenticated_client():
    """Cliente sin token: simula una petición sin credenciales (AC3)."""
    engine, maker = _create_engine_and_maker()
    requester_id = uuid.uuid4()

    async def prepare() -> None:
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    asyncio.run(prepare())
    _seed_users(maker, requester_id)

    fastapi_app.dependency_overrides[get_session] = _override_session(maker)
    # No se overridea get_current_user: sin token se espera 401.
    try:
        yield TestClient(fastapi_app), requester_id
    finally:
        fastapi_app.dependency_overrides.clear()
        asyncio.run(engine.dispose())


def _payload(requester_id: uuid.UUID, **overrides):
    payload = {
        "requester_id": str(requester_id),
        "title": "No hay conexión a la red",
        "description": "El laboratorio perdió conectividad.",
        "physical_location": "Edificio A, laboratorio 2",
        "channel": "portal",
        "urgency": 2,
        "impact": 2,
    }
    payload.update(overrides)
    return payload


# --- AC1: alta válida ---------------------------------------------------------


def test_alta_asigna_folio_y_estado_inicial(request_client) -> None:
    client, requester_id, _category_id = request_client

    response = client.post("/solicitudes", json=_payload(requester_id))

    assert response.status_code == 201, response.text
    body = response.json()
    assert body["folio"] == "SIG-0001"
    assert body["status"] == "registered"
    assert body["requester_id"] == str(requester_id)


def test_folio_es_consecutivo_y_persiste_entre_altas(request_client) -> None:
    client, requester_id, _category_id = request_client

    first = client.post("/solicitudes", json=_payload(requester_id, title="Primera solicitud"))
    second = client.post("/solicitudes", json=_payload(requester_id, title="Segunda solicitud"))

    assert first.status_code == 201, first.text
    assert second.status_code == 201, second.text
    assert first.json()["folio"] == "SIG-0001"
    assert second.json()["folio"] == "SIG-0002"


def test_alta_con_urgencia_e_impacto_distintos(request_client) -> None:
    client, requester_id, _category_id = request_client

    response = client.post(
        "/solicitudes", json=_payload(requester_id, urgency=3, impact=1)
    )

    assert response.status_code == 201, response.text
    body = response.json()
    assert body["urgency"] == 3
    assert body["impact"] == 1


# --- AC2: campos incompletos --------------------------------------------------


def test_rn02_rechaza_solicitante_inexistente_o_inactivo(request_client) -> None:
    client, _requester_id, _category_id = request_client

    response = client.post("/solicitudes", json=_payload(uuid.uuid4()))

    assert response.status_code == 422
    assert "requester" in response.json()["detail"]


def test_rn02_rechaza_solicitante_inactivo(request_client) -> None:
    client, _requester_id, _category_id = request_client
    client_id = uuid.uuid4()

    session_override = fastapi_app.dependency_overrides[get_session]

    async def add_inactive():
        async for session in session_override():
            session.add(
                User(
                    id=client_id,
                    institutional_id=f"inactive-{client_id.hex[:8]}",
                    full_name="Solicitante inactivo",
                    email=f"inactive-{client_id.hex[:8]}@example.test",
                    user_type=UserType.ACADEMIC,
                    is_active=False,
                )
            )
            await session.commit()

    asyncio.run(add_inactive())
    response = client.post("/solicitudes", json=_payload(requester_id=client_id))

    assert response.status_code == 422
    assert "inactive" in response.json()["detail"]


def test_rn03_rechaza_categoria_inexistente(request_client) -> None:
    client, requester_id, _category_id = request_client

    response = client.post(
        "/solicitudes",
        json=_payload(requester_id, category_id=str(uuid.uuid4())),
    )

    assert response.status_code == 422
    assert "category" in response.json()["detail"]


@pytest.mark.parametrize(
    "invalid_field",
    ["title", "description", "physical_location"],
)
def test_alta_rechaza_datos_obligatorios_invalidos(request_client, invalid_field) -> None:
    client, requester_id, _category_id = request_client
    payload = _payload(requester_id)
    payload[invalid_field] = ""

    response = client.post("/solicitudes", json=payload)

    assert response.status_code == 422


@pytest.mark.parametrize(
    ("urgency", "impact", "esperada"),
    [(3, 3, "P1"), (2, 2, "P2"), (1, 2, "P3"), (1, 1, "P4")],
)
def test_alta_calcula_la_prioridad_con_la_matriz(request_client, urgency, impact, esperada) -> None:
    client, requester_id, _category_id = request_client

    response = client.post(
        "/solicitudes", json=_payload(requester_id, urgency=urgency, impact=impact)
    )

    assert response.status_code == 201, response.text
    assert response.json()["priority"] == esperada


def test_alta_sin_urgencia_ni_impacto_deja_la_prioridad_vacia(request_client) -> None:
    client, requester_id, _category_id = request_client
    payload = _payload(requester_id)
    del payload["urgency"], payload["impact"]

    response = client.post("/solicitudes", json=payload)

    assert response.status_code == 201, response.text
    assert response.json()["priority"] is None


def test_alta_rechaza_la_edicion_directa_de_la_prioridad(request_client) -> None:
    client, requester_id, _category_id = request_client

    response = client.post("/solicitudes", json=_payload(requester_id, priority="P1"))

    assert response.status_code == 422
@pytest.mark.parametrize("invalid_value", [0, 4])
def test_alta_rechaza_urgencia_fuera_de_rango(request_client, invalid_value) -> None:
    client, requester_id, _category_id = request_client

    response = client.post(
        "/solicitudes", json=_payload(requester_id, urgency=invalid_value)
    )

    assert response.status_code == 422


@pytest.mark.parametrize("invalid_value", [0, 4])
def test_alta_rechaza_impacto_fuera_de_rango(request_client, invalid_value) -> None:
    client, requester_id, _category_id = request_client

    response = client.post(
        "/solicitudes", json=_payload(requester_id, impact=invalid_value)
    )

    assert response.status_code == 422


# --- AC3: credenciales inválidas ---------------------------------------------


def test_alta_sin_autenticacion_responde_401(unauthenticated_client) -> None:
    client, requester_id = unauthenticated_client

    response = client.post("/solicitudes", json=_payload(requester_id))

    assert response.status_code == 401
