"""Persistence gateway for users and their role assignments."""

import uuid

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.permissions import RoleName
from app.models.identity import Role, User, UserRole


class UsuarioRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_institutional_id(self, institutional_id: str) -> User | None:
        stmt = (
            select(User)
            .where(User.institutional_id == institutional_id)
            .options(selectinload(User.roles).selectinload(UserRole.role))
        )
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_by_id(self, user_id: uuid.UUID) -> User | None:
        stmt = (
            select(User)
            .where(User.id == user_id)
            .options(selectinload(User.roles).selectinload(UserRole.role))
            # Recarga los roles aunque el usuario ya esté en la sesión: tras un
            # `flush` sin `commit` la colección cargada antes quedaría obsoleta.
            .execution_options(populate_existing=True)
        )
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_role_by_name(self, name: RoleName) -> Role | None:
        stmt = select(Role).where(Role.name == name.value)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def add(self, user: User) -> User:
        self.session.add(user)
        await self.session.flush()
        await self.session.refresh(user)
        return user

    async def assign_role(self, user_id: uuid.UUID, role_id: uuid.UUID) -> None:
        self.session.add(UserRole(user_id=user_id, role_id=role_id))
        await self.session.flush()

    async def deactivate(self, user: User) -> User:
        user.is_active = False
        await self.session.flush()
        await self.session.refresh(user)
        return user

    async def list_active(self) -> list[User]:
        stmt = (
            select(User)
            .where(User.is_active.is_(True))
            .options(selectinload(User.roles).selectinload(UserRole.role))
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def update_fields(self, user: User, fields: dict) -> User:
        for key, value in fields.items():
            setattr(user, key, value)
        await self.session.flush()
        await self.session.refresh(user)
        return user

    async def replace_roles(self, user_id: uuid.UUID, role_id: uuid.UUID) -> None:
        await self.session.execute(delete(UserRole).where(UserRole.user_id == user_id))
        self.session.add(UserRole(user_id=user_id, role_id=role_id))
        await self.session.flush()

    async def commit(self) -> None:
        """Confirma la transacción; la llama el servicio que orquesta el caso de uso."""
        await self.session.commit()
