from collections.abc import Iterable

from sqlalchemy import select

from app.core.security import hash_password
from app.models.catalog import AreaServicio, Categoria, Especialidad, Turno
from app.models.enums import Priority
from app.models.identity import Role, User, UserRole
from app.models.notification import NotificationTemplate
from app.models.organization import OrganizationalUnit
from app.seeds.data import (
    CATEGORY_SEEDS,
    NOTIFICATION_TEMPLATE_SEEDS,
    PRIORITY_SEEDS,
    SERVICE_AREA_SEEDS,
    SHIFT_SEEDS,
    SPECIALTY_SEEDS,
    USER_SEEDS,
)


def _session_factory():
    from app.db.session import SessionLocal

    return SessionLocal


async def run_seed_categories(area_name: str = "Soporte técnico") -> int:
    """Create the default categories under an existing service area."""
    async with _session_factory()() as session:
        area = await session.scalar(select(AreaServicio).where(AreaServicio.name == area_name))
        if area is None:
            raise ValueError(
                f"Service area {area_name!r} does not exist; create it before seeding categories."
            )

        created = 0
        for name, description in CATEGORY_SEEDS:
            category = await session.scalar(select(Categoria).where(Categoria.name == name))
            if category is None:
                session.add(
                    Categoria(area_id=area.id, name=name, description=description, is_active=True)
                )
                created += 1

        await session.commit()
        return created


async def run_seed_organizational_units() -> int:
    """Create the default organizational unit used by the local catalog."""
    async with _session_factory()() as session:
        unit = await session.scalar(
            select(OrganizationalUnit).where(OrganizationalUnit.code == "SPT")
        )
        if unit is not None:
            return 0

        session.add(
            OrganizationalUnit(
                name="Soporte técnico",
                unit_type="department",
                code="SPT",
                is_active=True,
            )
        )
        await session.commit()
        return 1


async def run_seed_area(area_name: str = "Soporte técnico") -> int:
    """Create the default service area under the matching organizational unit."""
    async with _session_factory()() as session:
        area = await session.scalar(select(AreaServicio).where(AreaServicio.name == area_name))
        if area is not None:
            return 0

        unit = await session.scalar(
            select(OrganizationalUnit).where(OrganizationalUnit.code == "SPT")
        )
        if unit is None:
            raise ValueError("Organizational unit SPT does not exist; seed units first.")

        session.add(
            AreaServicio(
                unit_id=unit.id,
                name=area_name,
                description="Área de soporte técnico para el personal",
                is_active=True,
            )
        )
        await session.commit()
        return 1


async def run_seed_service_areas() -> int:
    """Crea las áreas de servicio predefinidas bajo la unidad SPT.

    Idempotente: omite las áreas cuyo nombre ya existe.
    """
    async with _session_factory()() as session:
        unit = await session.scalar(
            select(OrganizationalUnit).where(OrganizationalUnit.code == "SPT")
        )
        if unit is None:
            raise ValueError("Organizational unit SPT does not exist; seed units first.")

        created = 0
        for name in SERVICE_AREA_SEEDS:
            area = await session.scalar(select(AreaServicio).where(AreaServicio.name == name))
            if area is None:
                session.add(AreaServicio(unit_id=unit.id, name=name, is_active=True))
                created += 1

        await session.commit()
        return created


async def run_seed_specialties() -> int:
    """Crea las especialidades predefinidas de cada categoría sembrada.

    Idempotente: omite la pareja (categoría, especialidad) si ya existe.
    """
    async with _session_factory()() as session:
        created = 0
        for category_name, specialty_names in SPECIALTY_SEEDS.items():
            category = await session.scalar(
                select(Categoria).where(Categoria.name == category_name)
            )
            if category is None:
                raise ValueError(
                    f"Category {category_name!r} does not exist; seed categories first."
                )
            for name in specialty_names:
                specialty = await session.scalar(
                    select(Especialidad).where(
                        Especialidad.category_id == category.id, Especialidad.name == name
                    )
                )
                if specialty is None:
                    session.add(Especialidad(category_id=category.id, name=name, is_active=True))
                    created += 1

        await session.commit()
        return created


async def run_seed_shifts() -> int:
    """Crea los turnos predefinidos con su horario fijo.

    Idempotente: omite los turnos cuyo nombre ya existe.
    """
    async with _session_factory()() as session:
        created = 0
        for option in SHIFT_SEEDS:
            shift = await session.scalar(select(Turno).where(Turno.name == option.name))
            if shift is None:
                session.add(
                    Turno(
                        name=option.name,
                        start_minute=option.start_minute,
                        end_minute=option.end_minute,
                        is_active=True,
                    )
                )
                created += 1

        await session.commit()
        return created


async def run_seed_notification_templates() -> int:
    """Carga las plantillas de aviso del catálogo de eventos (S4-04).

    Idempotente: omite los códigos de evento que ya tienen plantilla y no
    sobrescribe los textos que se hayan editado en la base de datos.
    """
    async with _session_factory()() as session:
        created = 0
        for event_code, (subject, body) in NOTIFICATION_TEMPLATE_SEEDS.items():
            template = await session.scalar(
                select(NotificationTemplate).where(NotificationTemplate.event_code == event_code)
            )
            if template is None:
                session.add(
                    NotificationTemplate(
                        event_code=str(event_code), subject_template=subject, body_template=body
                    )
                )
                created += 1

        await session.commit()
        return created


async def run_seed_priorities() -> tuple[Priority, ...]:
    """Return the supported priorities; priorities are persisted as an enum value."""
    return PRIORITY_SEEDS


async def run_seed_users() -> int:
    """Create default user accounts for entering the system.

    Idempotent: skips users whose institutional_id already exists.
    Each seed user is assigned exactly one role via UserRole.
    """
    async with _session_factory()() as session:
        created = 0
        for data in USER_SEEDS:
            existing = await session.scalar(
                select(User).where(User.institutional_id == data["institutional_id"])
            )
            if existing is not None:
                continue

            user = User(
                institutional_id=data["institutional_id"],
                full_name=data["full_name"],
                email=data["email"],
                password_hash=hash_password(data["password"]),
                user_type=data["user_type"],
                support_level=data["support_level"],
                is_active=True,
            )
            session.add(user)
            await session.flush()

            role = await session.scalar(
                select(Role).where(Role.name == data["role"])
            )
            if role is None:
                raise ValueError(
                    f"Role {data['role']!r} does not exist; seed identity roles first."
                )

            session.add(
                UserRole(user_id=user.id, role_id=role.id)
            )
            created += 1

        await session.commit()
        return created


async def run_all(area_name: str = "Soporte técnico") -> dict[str, int]:
    units = await run_seed_organizational_units()
    areas = await run_seed_area(area_name)
    categories = await run_seed_categories(area_name)
    service_areas = await run_seed_service_areas()
    specialties = await run_seed_specialties()
    shifts = await run_seed_shifts()
    priorities = await run_seed_priorities()
    users = await run_seed_users()
    notifications = await run_seed_notification_templates()
    return {
        "organizational_units": units,
        "areas": areas,
        "categories": categories,
        "service_areas": service_areas,
        "specialties": specialties,
        "shifts": shifts,
        "priorities": len(priorities),
        "users": users,
        "notification_templates": notifications,
    }


def supported_priorities(values: Iterable[Priority] = PRIORITY_SEEDS) -> tuple[str, ...]:
    return tuple(priority.value for priority in values)
