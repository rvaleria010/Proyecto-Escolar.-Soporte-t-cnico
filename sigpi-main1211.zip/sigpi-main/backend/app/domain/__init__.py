"""Framework-independent business rules."""
