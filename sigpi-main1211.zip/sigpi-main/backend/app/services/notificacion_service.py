"""Notificaciones dentro de la aplicación (S4-05, HU-07.1).

Cuando ocurre un evento del ciclo de vida de una solicitud, el servicio redacta un aviso
con folio, categoría, prioridad, técnico y fecha compromiso y lo guarda para cada
destinatario. La campana de la interfaz (S4-06) lo consulta; no hay correo (queda fuera
del alcance del proyecto escolar, ver HU-07.3).
"""

import uuid
from collections.abc import Iterable, Mapping
from datetime import UTC, datetime

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import BusinessRuleError, NotFoundError
from app.core.logging import get_logger, log_event
from app.domain import eventos
from app.domain.eventos import ROL_JEFES, EventoAviso
from app.models.enums import (
    NotificationChannel,
    NotificationImportance,
    NotificationStatus,
    RequestStatus,
)
from app.models.notification import Notification
from app.models.request import Request
from app.repositories.notificacion_repository import NotificacionRepository
from app.services.sla_clock_service import fecha_compromiso, minutos_efectivos
from app.services.sla_service import as_utc
from app.templates.avisos.plantillas import PLANTILLAS_AVISO

logger = get_logger("notificaciones")

SIN_DATO = "—"

# Códigos de evento: alias de `app.domain.eventos.EventoAviso` (catálogo S4-04).
EVENTO_SOLICITUD_REGISTRADA = EventoAviso.SOLICITUD_REGISTRADA
EVENTO_SOLICITUD_ASIGNADA = EventoAviso.SOLICITUD_ASIGNADA
EVENTO_ESTATUS_CAMBIADO = EventoAviso.ESTATUS_CAMBIADO
EVENTO_SOLICITUD_RESUELTA = EventoAviso.SOLICITUD_RESUELTA
EVENTO_SOLICITUD_CERRADA = EventoAviso.SOLICITUD_CERRADA
EVENTO_RIESGO_SLA = EventoAviso.RIESGO_SLA
EVENTO_P1_SIN_ASIGNAR = EventoAviso.P1_SIN_ASIGNAR

# código de evento -> (asunto, cuerpo); fuente: `app.templates.avisos.plantillas`.
_PLANTILLAS_RESPALDO: dict[str, tuple[str, str]] = PLANTILLAS_AVISO

# Mismos textos que `STATUS_LABELS` del frontend (features/requests/request-labels.ts).
_ETIQUETAS_ESTATUS: dict[str, str] = {
    RequestStatus.REGISTERED: "Registrada",
    RequestStatus.PENDING_VERIFICATION: "Por verificar",
    RequestStatus.CLASSIFIED: "Clasificada",
    RequestStatus.PENDING_REVIEW: "En revisión",
    RequestStatus.ASSIGNED: "Asignada",
    RequestStatus.IN_PROGRESS: "En proceso",
    RequestStatus.WAITING: "En espera",
    RequestStatus.ESCALATED: "Escalada",
    RequestStatus.RESOLVED: "Resuelta",
    RequestStatus.CLOSED: "Cerrada",
    RequestStatus.CLOSED_UNVERIFIED: "Cerrada sin verificar",
}

EVENTOS_CONOCIDOS: frozenset[str] = frozenset(_PLANTILLAS_RESPALDO)

_ASUNTO_MAX = 240  # longitud de `notifications.subject`

SIN_TECNICO_ASIGNADO = "Sin técnico asignado: la solicitud necesita asignarse."


class _SafeDict(dict[str, str]):
    """Un campo que falte en el contexto se muestra como «—» en lugar de fallar."""

    def __missing__(self, key: str) -> str:
        return SIN_DATO


def _ahora() -> datetime:
    return datetime.now(UTC)


def _formatear_fecha(value: datetime | None) -> str:
    if value is None:
        return SIN_DATO
    return as_utc(value).strftime("%d/%m/%Y %H:%M UTC")


def _asignacion_vigente(request: Request):
    vigentes = [a for a in request.assignments if a.unassigned_at is None]
    if not vigentes:
        return None
    return max(vigentes, key=lambda a: as_utc(a.assigned_at))


def _tecnico_vigente(request: Request) -> str:
    actual = _asignacion_vigente(request)
    return actual.technician.full_name if actual is not None else "Sin asignar"


def _formatear_minutos(minutos: float) -> str:
    """Duración legible: «2 h 05 min», «45 min»."""
    total = max(0, int(minutos))
    horas, resto = divmod(total, 60)
    return f"{horas} h {resto:02d} min" if horas else f"{resto} min"


def _contexto(request: Request, extra: Mapping[str, str] | None = None) -> dict[str, str]:
    datos = {
        "folio": request.folio,
        "titulo": request.title,
        "categoria": request.category.name if request.category else "Sin clasificar",
        "prioridad": str(request.priority) if request.priority else SIN_DATO,
        "tecnico": _tecnico_vigente(request),
        "estado": _ETIQUETAS_ESTATUS.get(request.status, str(request.status)),
        "fecha_compromiso": _formatear_fecha(fecha_compromiso(request)),
    }
    if extra:
        datos.update(extra)
    return datos


class NotificacionService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session
        self._repository = NotificacionRepository(session)

    # ------------------------------------------------------------------ emisión

    async def notificar_evento(
        self,
        event_code: str,
        request_id: uuid.UUID,
        recipient_ids: Iterable[uuid.UUID],
        *,
        importance: NotificationImportance = NotificationImportance.NORMAL,
        extra: Mapping[str, str] | None = None,
        ahora: datetime | None = None,
        nota: str | None = None,
        confirmar: bool = True,
    ) -> list[Notification]:
        """Guarda un aviso por destinatario para un evento de una solicitud.

        Los destinatarios repetidos se avisan una sola vez. Si la lista queda vacía no se
        guarda nada. Un código sin plantilla es un error de programación: se rechaza.
        `nota` se agrega al final del cuerpo. Con `confirmar=False` los avisos quedan en la
        transacción en curso y el commit lo hace quien orquesta.
        """
        destinatarios = list(dict.fromkeys(recipient_ids))
        if not destinatarios:
            return []

        plantilla = await self._repository.get_template(event_code)
        if plantilla is not None:
            asunto_tpl, cuerpo_tpl = plantilla.subject_template, plantilla.body_template
        elif event_code in _PLANTILLAS_RESPALDO:
            asunto_tpl, cuerpo_tpl = _PLANTILLAS_RESPALDO[event_code]
        else:
            raise BusinessRuleError(f"El evento «{event_code}» no tiene plantilla de aviso.")

        request = await self._repository.get_request_context(request_id)
        if request is None:
            raise NotFoundError(f"La solicitud {request_id} no existe.")

        datos = _SafeDict(_contexto(request, extra))
        asunto = asunto_tpl.format_map(datos)[:_ASUNTO_MAX]
        cuerpo = cuerpo_tpl.format_map(datos)
        if nota:
            cuerpo = f"{cuerpo}\n{nota}"
        corte = ahora or _ahora()

        avisos = [
            Notification(
                template_id=plantilla.id if plantilla is not None else None,
                request_id=request.id,
                recipient_id=destinatario,
                channel=NotificationChannel.IN_APP,
                subject=asunto,
                body=cuerpo,
                status=NotificationStatus.SENT,
                importance=importance,
                sent_at=corte,
                created_at=corte,
            )
            for destinatario in destinatarios
        ]
        guardados = await self._repository.add_many(avisos)
        if confirmar:
            await self._session.commit()
        log_event(
            logger,
            "aviso_emitido",
            evento=event_code,
            folio=request.folio,
            destinatarios=len(guardados),
            importancia=str(importance),
        )
        return guardados

    async def emitir(
        self, evento: EventoAviso, request_id: uuid.UUID, *, ahora: datetime | None = None
    ) -> list[Notification]:
        """Avisa un evento del ciclo de vida a quienes indica el catálogo (S4-07, HU-07.1).

        Los destinatarios salen de `domain.eventos.destinatarios`: el solicitante, el
        técnico vigente y, si el evento lo pide, los jefes de servicio activos. No confirma:
        el aviso queda en la transacción del cambio y la confirma quien orquesta.
        """
        contexto = await self._repository.get_request_context(request_id)
        if contexto is None:
            raise NotFoundError(f"La solicitud {request_id} no existe.")
        asignacion = _asignacion_vigente(contexto)
        regla = eventos.CATALOGO_EVENTOS[EventoAviso(evento)]
        jefes = (
            await self._repository.list_active_user_ids_with_role(ROL_JEFES)
            if eventos.Destinatario.JEFES in regla.destinatarios
            else []
        )
        destinatarios = eventos.destinatarios(
            evento,
            contexto.requester_id,
            asignacion.technician_id if asignacion is not None else None,
            jefes,
        )
        return await self.notificar_evento(
            evento,
            contexto.id,
            destinatarios,
            importance=regla.importancia,
            ahora=ahora,
            confirmar=False,
        )

    async def alerta_riesgo(self, request: Request, ahora: datetime) -> list[Notification]:
        """Avisa que la solicitud llegó al umbral de riesgo del SLA (S4-09, HU-07.2).

        Reciben el aviso el técnico vigente y los usuarios activos con el rol de jefe de
        servicio; si no hay técnico, solo los jefes y el cuerpo lo indica. En `extra` van
        el porcentaje consumido y el tiempo restante. No confirma: el monitor marca la
        solicitud y confirma todo en una sola transacción.
        """
        contexto = await self._repository.get_request_context(request.id)
        if contexto is None:
            raise NotFoundError(f"La solicitud {request.id} no existe.")

        asignacion = _asignacion_vigente(contexto)
        tecnico_id = asignacion.technician_id if asignacion is not None else None
        jefes = await self._repository.list_active_user_ids_with_role(ROL_JEFES)
        destinatarios = eventos.destinatarios(EventoAviso.RIESGO_SLA, None, tecnico_id, jefes)

        comprometidos = (
            contexto.service_level_version.resolution_minutes
            if contexto.service_level_version is not None
            else 0
        )
        consumidos = minutos_efectivos(contexto, ahora)
        porcentaje = round(100 * consumidos / comprometidos) if comprometidos else 100
        restante = _formatear_minutos(comprometidos - consumidos)

        lineas = [f"Tiempo consumido: {porcentaje} % · Tiempo restante: {restante}"]
        if tecnico_id is None:
            lineas.append(SIN_TECNICO_ASIGNADO)

        return await self.notificar_evento(
            EventoAviso.RIESGO_SLA,
            contexto.id,
            destinatarios,
            importance=eventos.importancia(EventoAviso.RIESGO_SLA),
            extra={"porcentaje_consumido": f"{porcentaje} %", "tiempo_restante": restante},
            ahora=ahora,
            nota="\n".join(lineas),
            confirmar=False,
        )

    # ----------------------------------------------------------------- consulta

    async def listar(
        self,
        user_id: uuid.UUID,
        *,
        only_unread: bool = False,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Notification]:
        return await self._repository.list_for_recipient(
            user_id, only_unread=only_unread, limit=limit, offset=offset
        )

    async def contar_no_leidos(self, user_id: uuid.UUID) -> int:
        return await self._repository.count_unread(user_id)

    async def marcar_leido(
        self, user_id: uuid.UUID, notification_id: uuid.UUID, ahora: datetime | None = None
    ) -> Notification:
        aviso = await self._repository.get_for_recipient(notification_id, user_id)
        if aviso is None:
            raise NotFoundError("El aviso no existe.")
        return await self._repository.mark_read(aviso, ahora or _ahora())

    async def marcar_todos_leidos(self, user_id: uuid.UUID, ahora: datetime | None = None) -> int:
        return await self._repository.mark_all_read(user_id, ahora or _ahora())
