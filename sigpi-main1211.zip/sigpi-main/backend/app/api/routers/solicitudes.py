"""HTTP endpoints for service requests (HU-01.1, HU-01.3)."""

import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.dependencies import get_current_user, require_permission
from app.core.permissions import Permission, RoleName
from app.db.session import get_session
from app.integrations.directory_client import StubDirectoryClient
from app.models.enums import Priority, RequestStatus
from app.models.identity import User
from app.repositories.solicitud_repository import SolicitudRepository
from app.schemas.request import (
    RequestAssistedCreate,
    RequestCreate,
    RequestPage,
    RequestRead,
    RequestWaitCreate,
)
from app.services.clasificacion_service import ClasificacionService
from app.services.sla_clock_service import (
    EstadoInvalidoError,
    SlaClockService,
    SolicitudNoEncontradaError,
)
from app.services.solicitud_service import SolicitudService, SolicitudValidationError

router = APIRouter(prefix="/solicitudes", tags=["solicitudes"])


def get_clasificacion_service(
    session: AsyncSession = Depends(get_session),
) -> ClasificacionService:
    return ClasificacionService(session)


def get_solicitud_service(
    session: AsyncSession = Depends(get_session),
    clasificacion: ClasificacionService = Depends(get_clasificacion_service),
) -> SolicitudService:
    return SolicitudService(
        SolicitudRepository(session),
        session,
        directory=StubDirectoryClient(),
        clasificacion=clasificacion,
    )


def get_sla_clock_service(
    session: AsyncSession = Depends(get_session),
) -> SlaClockService:
    return SlaClockService(session)


@router.post("", response_model=RequestRead, status_code=status.HTTP_201_CREATED)
async def create_request(
    payload: RequestCreate,
    current_user: User = Depends(get_current_user),
    service: SolicitudService = Depends(get_solicitud_service),
) -> RequestRead:
    try:
        result = await service.create_request(payload, registered_by_id=current_user.id)
        return RequestRead.model_validate(result)
    except SolicitudValidationError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)
        ) from exc


@router.get("", response_model=RequestPage)
async def list_requests(
    q: str | None = Query(default=None, max_length=120),
    estatus: RequestStatus | None = Query(default=None, alias="status"),
    prioridad: Priority | None = Query(default=None, alias="priority"),
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    user: User = Depends(require_permission(Permission.REQUESTS_READ)),
    service: SolicitudService = Depends(get_solicitud_service),
) -> RequestPage:
    """Listado con búsqueda (`q`), filtros por estatus y prioridad y paginación.

    El personal ve todas las solicitudes; quien solo tiene el rol de solicitante ve
    únicamente las suyas.
    """
    ve_todas = any(ur.role is not None and ur.role.name != RoleName.REQUESTER for ur in user.roles)
    return await service.listar(
        texto=q,
        status=estatus,
        priority=prioridad,
        requester_id=None if ve_todas else user.id,
        limit=limit,
        offset=offset,
    )


@router.post("/asistido", response_model=RequestRead, status_code=status.HTTP_201_CREATED)
async def create_assisted_request(
    payload: RequestAssistedCreate,
    technician: User = Depends(require_permission(Permission.REQUESTS_CREATE_ASSISTED)),
    service: SolicitudService = Depends(get_solicitud_service),
) -> RequestRead:
    try:
        result = await service.create_assisted_request(payload, registered_by_id=technician.id)
        return RequestRead.model_validate(result)
    except SolicitudValidationError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)
        ) from exc


@router.post("/{request_id}/espera", response_model=RequestRead)
async def put_request_on_hold(
    request_id: uuid.UUID,
    payload: RequestWaitCreate,
    technician: User = Depends(require_permission(Permission.REQUESTS_UPDATE)),
    service: SlaClockService = Depends(get_sla_clock_service),
) -> RequestRead:
    try:
        result = await service.suspender(request_id, technician.id, payload.reason, payload.detail)
    except SolicitudNoEncontradaError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    except EstadoInvalidoError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    return RequestRead.model_validate(result)


@router.post("/{request_id}/reanudar", response_model=RequestRead)
async def resume_request(
    request_id: uuid.UUID,
    technician: User = Depends(require_permission(Permission.REQUESTS_UPDATE)),
    service: SlaClockService = Depends(get_sla_clock_service),
) -> RequestRead:
    try:
        result = await service.reanudar(request_id, technician.id)
    except SolicitudNoEncontradaError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    except EstadoInvalidoError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    return RequestRead.model_validate(result)