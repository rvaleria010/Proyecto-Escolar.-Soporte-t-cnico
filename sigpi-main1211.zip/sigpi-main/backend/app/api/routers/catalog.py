import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.dependencies import AuditContext, get_audit_context, require_permission
from app.core.permissions import Permission
from app.db.session import get_session
from app.models.identity import User
from app.models.organization import OrganizationalUnit
from app.repositories.auditoria_repository import AuditoriaRepository
from app.repositories.catalog_repository import (
    CategoryRepository,
    ServiceAreaRepository,
    ShiftRepository,
    SpecialtyRepository,
    TechnicianRepository,
)
from app.schemas.catalog import (
    CatalogOptionsRead,
    CategoryCreate,
    CategoryRead,
    OrganizationalUnitRead,
    ServiceAreaCreate,
    ServiceAreaRead,
    ShiftCreate,
    ShiftRead,
    SpecialtyCreate,
    SpecialtyRead,
    TechnicianProfileUpdate,
    TechnicianRead,
)
from app.services.auditoria_service import AuditoriaService
from app.services.catalog_service import CatalogService, CatalogValidationError

router = APIRouter(prefix="/catalog", tags=["catalog"])


def get_catalog_service(session: AsyncSession = Depends(get_session)) -> CatalogService:
    return CatalogService(
        areas=ServiceAreaRepository(session),
        categories=CategoryRepository(session),
        specialties=SpecialtyRepository(session),
        shifts=ShiftRepository(session),
        technicians=TechnicianRepository(session),
        auditoria=AuditoriaService(AuditoriaRepository(session)),
    )


# Las altas y la edición de técnicos exigen sesión con permiso de gestión del catálogo.
_GESTIONA_CATALOGO = [Depends(require_permission(Permission.CATALOG_MANAGE))]


def _to_technician_read(user: User) -> TechnicianRead:
    return TechnicianRead(
        id=user.id,
        full_name=user.full_name,
        support_level=user.support_level,
        shift_id=user.shift_id,
        max_load=user.max_load,
        is_active=user.is_active,
        specialty_ids=[specialty.id for specialty in user.specialties],
    )


def _unprocessable(exc: CatalogValidationError) -> HTTPException:
    return HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc))


@router.get("/options", response_model=CatalogOptionsRead)
async def list_options(service: CatalogService = Depends(get_catalog_service)):
    return service.get_options()


@router.get("/areas", response_model=list[ServiceAreaRead])
async def list_areas(service: CatalogService = Depends(get_catalog_service)):
    return await service.list_areas()


@router.get("/organizational-units", response_model=list[OrganizationalUnitRead])
async def list_organizational_units(
    session: AsyncSession = Depends(get_session),
):
    result = await session.scalars(
        select(OrganizationalUnit)
        .where(OrganizationalUnit.is_active.is_(True))
        .order_by(OrganizationalUnit.name)
    )
    return list(result)


@router.post(
    "/areas",
    response_model=ServiceAreaRead,
    status_code=status.HTTP_201_CREATED,
    dependencies=_GESTIONA_CATALOGO,
)
async def create_area(
    payload: ServiceAreaCreate,
    service: CatalogService = Depends(get_catalog_service),
    contexto: AuditContext = Depends(get_audit_context),
):
    return await service.create_area(payload, contexto)


@router.get("/categories", response_model=list[CategoryRead])
async def list_categories(
    area_id: uuid.UUID | None = None, service: CatalogService = Depends(get_catalog_service)
):
    return await service.list_categories(area_id=area_id)


@router.post(
    "/categories",
    response_model=CategoryRead,
    status_code=status.HTTP_201_CREATED,
    dependencies=_GESTIONA_CATALOGO,
)
async def create_category(
    payload: CategoryCreate,
    service: CatalogService = Depends(get_catalog_service),
    contexto: AuditContext = Depends(get_audit_context),
):
    try:
        return await service.create_category(payload, contexto)
    except CatalogValidationError as exc:
        raise _unprocessable(exc) from exc


@router.get("/specialties", response_model=list[SpecialtyRead])
async def list_specialties(
    category_id: uuid.UUID | None = None, service: CatalogService = Depends(get_catalog_service)
):
    return await service.list_specialties(category_id=category_id)


@router.post(
    "/specialties",
    response_model=SpecialtyRead,
    status_code=status.HTTP_201_CREATED,
    dependencies=_GESTIONA_CATALOGO,
)
async def create_specialty(
    payload: SpecialtyCreate,
    service: CatalogService = Depends(get_catalog_service),
    contexto: AuditContext = Depends(get_audit_context),
):
    try:
        return await service.create_specialty(payload, contexto)
    except CatalogValidationError as exc:
        raise _unprocessable(exc) from exc


@router.get("/shifts", response_model=list[ShiftRead])
async def list_shifts(service: CatalogService = Depends(get_catalog_service)):
    return await service.list_shifts()


@router.post(
    "/shifts",
    response_model=ShiftRead,
    status_code=status.HTTP_201_CREATED,
    dependencies=_GESTIONA_CATALOGO,
)
async def create_shift(
    payload: ShiftCreate,
    service: CatalogService = Depends(get_catalog_service),
    contexto: AuditContext = Depends(get_audit_context),
):
    try:
        return await service.create_shift(payload, contexto)
    except CatalogValidationError as exc:
        raise _unprocessable(exc) from exc


@router.get("/technicians", response_model=list[TechnicianRead])
async def list_technicians(
    specialty_id: uuid.UUID | None = None,
    service: CatalogService = Depends(get_catalog_service),
):
    technicians = await service.list_technicians(specialty_id=specialty_id)
    return [_to_technician_read(t) for t in technicians]


@router.patch(
    "/technicians/{user_id}", response_model=TechnicianRead, dependencies=_GESTIONA_CATALOGO
)
async def update_technician(
    user_id: uuid.UUID,
    payload: TechnicianProfileUpdate,
    service: CatalogService = Depends(get_catalog_service),
    contexto: AuditContext = Depends(get_audit_context),
):
    try:
        technician = await service.update_technician_profile(user_id, payload, contexto)
    except CatalogValidationError as exc:
        raise _unprocessable(exc) from exc
    return _to_technician_read(technician)
